from django.http import HttpResponse
import boto3
import json
import time
from django.views.decorators.csrf import csrf_exempt

def index(request):
    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:GetFoodItems',
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)




@csrf_exempt
def login(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:LogIn',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)


@csrf_exempt
def authenticate(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:Authenticate',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)



@csrf_exempt
def logout(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:LogOut',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)



@csrf_exempt
def rekognition(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:Rekognition',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)




@csrf_exempt
def computeOrderPrice(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:ComputeOrderPrice',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)




@csrf_exempt
def submitOrder(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:Workflow',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(1)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
        else:
            state = client.get_execution_history(
                executionArn=response['executionArn'],
                maxResults=50,
                reverseOrder=False,
                includeExecutionData=False
            )
            for i in state['events']:
                if i['type'] == "PassStateEntered":
                    return HttpResponse("{\"response\": \"funciona\"}")
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        return HttpResponse("{\"response\": \"funciona\"}")
    else:
        return HttpResponse("{\"response\": \"error\"}")

    return HttpResponse(response)





def listOrders(request):
    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:ListOrders',
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)


def completeOrder(request):
    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:CompleteOrder',
    )

    execution_description = {}
    while True:
        time.sleep(0.8)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)


@csrf_exempt
def confirmDelivery(request):
    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:ConfirmDelivery',
        input= str(request.body, 'utf-8')
    )

    execution_description = {}
    while True:
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)




def getActivity(request):

    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:GetActivity'
    )

    execution_description = {}
    while True:
        time.sleep(1)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)

    return HttpResponse(response_string)



def results(request, question_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % question_id)




def details(request, meal_id):
    client = boto3.client('stepfunctions', region_name='us-east-1')
    response = client.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:860683039334:stateMachine:MyStateMachine',
        #name='dev-hassan-pipeline-sf',
        input= '{ \"value\": %s, \"str\": {\"nome\": \"joao\"} }' % meal_id
    )
    x = 0
    execution_description = {}
    while True:
        x+=1
        time.sleep(0.2)
        execution_description = client.describe_execution(
            executionArn=response['executionArn']
        )
        if execution_description['status'] != 'RUNNING':
            break
    
    response_string = ""
    if execution_description['status'] == 'SUCCEEDED':
        response_string = execution_description['output'] 
    else:
        response_string = str(execution_description)
    sleep_time = " Sleep time: %s" % x

    return HttpResponse(response_string + sleep_time)


