from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('staff/login/', views.login, name='login'),
    path('staff/logout/', views.logout, name='logout'),
    path('staff/authenticate/', views.authenticate, name='authenticate'),
    path('staff/list_orders/', views.listOrders, name='listOrders'),
    path('staff/complete_order/', views.completeOrder, name='completeOrder'),
    path('rekognition/', views.rekognition, name='rekognition'),
    path('compute_order_price/', views.computeOrderPrice, name='computeOrderPrice'),
    path('submit_order/', views.submitOrder, name='submitOrder'),
    path('confirm_delivery/', views.confirmDelivery, name='confirmDelivery'),
    path('get_activity/', views.getActivity, name='getActivity'),
    path('<int:meal_id>/', views.details, name='details'),
    path('<int:question_id>/results/', views.results, name='results'),
]