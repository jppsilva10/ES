from django.apps import AppConfig


class MealInfoConfig(AppConfig):
    name = 'meal_info'
